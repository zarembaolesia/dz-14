Installation on 3.x

 

Installation on 4.x

Step1:  extract zip file
Step2:  extract vqmod2.6.7.ocmod.zip file
Step3:  upload "vqmod" folder directly via ftp or file manager
Step4:  open link  www.yoursitename/vqmod/install
Step5:  write your admin directory link if change otherwise remain it as it is admin.
Step6: Login to admin and Install extension logincheckout.ocmod.zip

