<?php
// Text
$_['text_captcha'] = 'Захист від роботів';

// Entry
$_['entry_captcha'] = 'Введіть код у полі нижче';

// Error
$_['error_captcha'] = 'Перевірочний код не співпадає із зображенням!';