<?php
// Heading
$_['heading_title'] = 'Самовивіз';

// Text
$_['text_description'] = 'Самовивіз із магазину';