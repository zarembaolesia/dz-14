<?php
// Heading
$_['heading_title'] = 'За одиницю товару';

// Text
$_['text_description'] = 'Вартість доставки з оплатою за одиницю товару';