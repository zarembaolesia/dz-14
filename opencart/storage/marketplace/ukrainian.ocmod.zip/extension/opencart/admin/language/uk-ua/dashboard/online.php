<?php
// Heading
$_['heading_title'] = 'Клієнти Online';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Редагування';
$_['text_view'] = 'детальніше...';

// Entry
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';
$_['entry_width'] = 'Ширина';

// Error
$_['error_permission'] = 'У Вас немає прав для керування цим розширенням!';