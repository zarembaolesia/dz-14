<?php
// Heading
$_['heading_title'] = 'Стандартний шаблон';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Редагування';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни налаштувань!';