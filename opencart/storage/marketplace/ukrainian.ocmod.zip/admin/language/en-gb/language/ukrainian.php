<?php
// Heading
$_['heading_title']    = 'Ukrainian Language';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Ukrainian Language!';
$_['text_edit']        = 'Edit Ukrainian Language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Ukrainian Language!';