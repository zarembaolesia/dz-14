<?php
// Heading
$_['heading_title'] = 'Повідомлення';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список повідомлень';

// Column
$_['column_message'] = 'Повідомлення';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для керування Повідомленнями!';