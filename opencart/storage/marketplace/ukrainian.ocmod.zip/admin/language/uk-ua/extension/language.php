<?php
// Heading
$_['heading_title'] = 'Мови';

// Text
$_['text_success'] = 'Ви успішно змінили мови!';
$_['text_list'] = 'Список мов';

// Column
$_['column_name'] = 'Назва мови';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Попередження: Ви не маєте дозволу змінювати мови!';
$_['error_extension'] = 'Попередження: Розширення не існує!';