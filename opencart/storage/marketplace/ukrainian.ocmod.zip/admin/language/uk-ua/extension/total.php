<?php
// Heading
$_['heading_title'] = 'Суми замовлення';

// Text
$_['text_success'] = 'Налаштування успішно оновлено!';

// Column
$_['column_name'] = 'Суми замовлення';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для редагування розширення Суми замовлення!';
$_['error_extension'] = 'Увага: Розширення не існує!';