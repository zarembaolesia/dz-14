<?php
// Heading
$_['heading_title'] = 'Головна панель';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список модулів';

// Column
$_['column_name'] = 'Назва';
$_['column_width'] = 'Ширина';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для редагування розширення Головна панель!';
$_['error_extension'] = 'Увага: Розширення не існує!';