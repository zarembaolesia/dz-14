<?php
// Heading
$_['heading_title'] = 'Звіти';

// Text
$_['text_success'] = 'Налаштування успішно оновлено!';
$_['text_list'] = 'Список звітів';

// Column
$_['column_name'] = 'Ім\'я';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для редагування розширення Звіти!';
$_['error_extension'] = 'Увага: Розширення не існує!';