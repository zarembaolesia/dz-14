<?php
// Heading
$_['heading_title'] = 'Звіти';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_type'] = 'Виберіть бажаний звіт';
$_['text_filter'] = 'Фільтр';