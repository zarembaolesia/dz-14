<?php
// Heading
$_['heading_title'] = 'Стартові дії';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список дій';

// Column
$_['column_code'] = 'Код дії';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Увага: У вас немає прав для керування Стартовими діями!';