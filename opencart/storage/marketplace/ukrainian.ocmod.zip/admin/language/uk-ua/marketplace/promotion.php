<?php
// Text
$_['text_recommended'] = 'Рекомендації';
$_['text_install'] = 'Встановити';
$_['text_uninstall'] = 'Деінсталювати';
$_['text_delete'] = 'Видалити';
