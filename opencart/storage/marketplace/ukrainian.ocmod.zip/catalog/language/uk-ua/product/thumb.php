<?php
// Text
$_['text_price'] = 'Ціна:';
$_['text_tax'] = 'Без ПДВ:';