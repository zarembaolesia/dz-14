<?php
// Text
$_['text_category']  = 'Меню';
$_['text_all'] = 'Показати всі';