<?php
// Text
$_['text_items'] = '%s товарів (%s)';
$_['text_points'] = 'Бонусні бали';
$_['text_subscription'] = 'Передплата';
$_['text_subscription_trial'] = '%s кожен %d %s(ів) для %d платежу(ів) потім ';
$_['text_subscription_duration'] = '%s кожен %d %s(ів) для %d платежу(ів)';
$_['text_subscription_cancel'] = '%s кожен %d %s(ів) поки не скасують';
$_['text_day'] = 'день';
$_['text_week'] = 'тиждень';
$_['text_semi_month'] = 'півмісяця';
$_['text_month'] = 'місяць';
$_['text_year'] = 'рік';
$_['text_no_results'] = 'Ваш кошик порожній!';
$_['text_cart'] = 'Перейти до корзини';
$_['text_checkout'] = 'Оформити замовлення';