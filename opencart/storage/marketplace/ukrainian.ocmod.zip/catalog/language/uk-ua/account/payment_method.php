<?php
// Heading
$_['heading_title'] = 'Способи оплати';

// Text
$_['text_account'] = 'Акаунт';
$_['text_payment_method'] = 'Способи оплати';
$_['text_success'] = 'Ваш спосіб оплати був успішно вилучений';
$_['text_no_results'] = 'Немає способів оплати у вашому обліковому записі.';

// Column
$_['column_payment_method'] = 'Спосіб оплати';
$_['column_type'] = 'Тип';
$_['column_date_expire'] = 'Дата закінчення';
$_['column_action'] = 'Дія';

// Error
$_['error_payment_method'] = 'Попередження: Не вдалося знайти спосіб оплати!';